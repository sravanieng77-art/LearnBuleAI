const pages=[...document.querySelectorAll('.page')];
const navs=[...document.querySelectorAll('.nav')];
const titles={dashboard:'Good morning, Rithvik 👋',profile:'Student Profile',performance:'Performance Analysis',skills:'Skill Gap Identification',learning:'Learning & Recommendations',roadmap:'Personalized Learning Path',progress:'Progress Tracking',career:'Career Path',calendar:'Calendar & Tasks',ai:'LearnBule AI'};

function showPage(id){
  pages.forEach(p=>p.classList.toggle('active-page',p.id===id));
  navs.forEach(n=>n.classList.toggle('active',n.dataset.page===id));
  document.getElementById('pageTitle').textContent=titles[id]||'LearnBule AI';
  if(id==='calendar') renderCalendar();
  window.scrollTo({top:0,behavior:'smooth'});
}
navs.forEach(n=>n.addEventListener('click',()=>showPage(n.dataset.page)));
function toggleSidebar(){document.querySelector('.sidebar').classList.toggle('open')}
function showToast(msg){const t=document.getElementById('toast');t.textContent=msg;t.style.display='block';setTimeout(()=>t.style.display='none',2400)}

let chart;
function chartData(type){
  return type==='month'
    ? {labels:['Week 1','Week 2','Week 3','Week 4'],data:[62,71,76,84]}
    : {labels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],data:[68,72,61,79,74,88,84]};
}
function makeChart(id,type='week'){
 const el=document.getElementById(id); if(!el)return;
 const d=chartData(type);
 return new Chart(el,{type:'line',data:{labels:d.labels,datasets:[{label:'Score %',data:d.data,borderWidth:3,tension:.35,fill:false}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{min:0,max:100,ticks:{stepSize:20}}}}});
}
function updateChart(type){if(chart)chart.destroy();chart=makeChart('performanceChart',type);makeChart('performanceChart2',type)}
document.addEventListener('DOMContentLoaded',()=>{chart=makeChart('performanceChart');makeChart('performanceChart2');renderCalendar()});

let calDate=new Date();
function changeMonth(n){calDate.setMonth(calDate.getMonth()+n);renderCalendar()}
function renderCalendar(){
 const title=document.getElementById('monthName'),grid=document.getElementById('calendarGrid');if(!title||!grid)return;
 const y=calDate.getFullYear(),m=calDate.getMonth();title.textContent=new Date(y,m,1).toLocaleString('en',{month:'long',year:'numeric'});
 const first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate();grid.innerHTML='';
 for(let i=0;i<first;i++)grid.appendChild(document.createElement('span'));
 for(let d=1;d<=days;d++){let b=document.createElement('button');b.textContent=d;if(d===new Date().getDate()&&m===new Date().getMonth()&&y===new Date().getFullYear())b.className='today';b.onclick=()=>showToast('Selected '+d+' '+title.textContent);grid.appendChild(b)}
}
function addTask(){const name=prompt('Enter task name');if(name)showToast('Task "'+name+'" added to your plan')}

function askAI(q){document.getElementById('aiInput').value=q;sendAI()}
function sendAI(){
 const input=document.getElementById('aiInput'),q=input.value.trim();if(!q)return;
 const chat=document.getElementById('chat');
 chat.innerHTML+=`<div class="bubble user"><b>You</b><p>${escapeHtml(q)}</p></div>`;
 let answer='Based on your current profile, recent performance and roadmap, focus on the highest-priority skill gap first. I recommend 30–45 minutes of focused practice, followed by a short assessment.';
 const x=q.toLowerCase();
 if(x.includes('today'))answer='Today, focus on <b>SQL JOIN practice</b> for 25 minutes because SQL is currently your largest identified skill gap. Then solve 5 easy algorithm problems and finish with 10 aptitude questions.';
 else if(x.includes('sql'))answer='Your current SQL score is 47% compared with a target of 75%. Start with SELECT, WHERE and JOINs, then practice aggregation. Retake a short test after practice.';
 else if(x.includes('roadmap'))answer='Your current roadmap is Java Fundamentals ✓ → OOP & Data Structures (current) → SQL & JDBC → Web Development → Projects & Interviews. Your next major gap is SQL.';
 else if(x.includes('algorithm'))answer='Your algorithm performance is improving, but sorting and searching have recent mistakes. Practice Arrays → Searching → Sorting → Recursion before moving to harder problems.';
 chat.innerHTML+=`<div class="bubble ai"><b>LearnBule AI</b><p>${answer}</p></div>`;
 chat.scrollTop=chat.scrollHeight;input.value='';
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}

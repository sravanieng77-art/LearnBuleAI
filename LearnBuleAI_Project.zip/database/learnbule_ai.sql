CREATE DATABASE IF NOT EXISTS learnbule_ai;
USE learnbule_ai;

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    college VARCHAR(150),
    branch VARCHAR(100),
    year INT,
    semester INT,
    section VARCHAR(20),
    career_goal VARCHAR(100)
);

CREATE TABLE skills (
    skill_id INT AUTO_INCREMENT PRIMARY KEY,
    skill_name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(100)
);

CREATE TABLE student_skills (
    student_id INT,
    skill_id INT,
    skill_level ENUM('Beginner','Basic','Intermediate','Advanced') DEFAULT 'Beginner',
    score DECIMAL(5,2) DEFAULT 0,
    PRIMARY KEY(student_id, skill_id),
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY(skill_id) REFERENCES skills(skill_id) ON DELETE CASCADE
);

CREATE TABLE assessments (
    assessment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    category VARCHAR(100) NOT NULL,
    topic VARCHAR(100),
    score DECIMAL(5,2) NOT NULL,
    max_score DECIMAL(5,2) DEFAULT 100,
    mistakes INT DEFAULT 0,
    assessment_date DATE NOT NULL,
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    difficulty VARCHAR(50),
    resource_url TEXT
);

CREATE TABLE student_courses (
    student_id INT,
    course_id INT,
    progress DECIMAL(5,2) DEFAULT 0,
    status VARCHAR(30) DEFAULT 'Not Started',
    PRIMARY KEY(student_id, course_id),
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY(course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);

CREATE TABLE coding_practice (
    practice_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    topic VARCHAR(100),
    difficulty VARCHAR(50),
    score DECIMAL(5,2),
    solved BOOLEAN DEFAULT FALSE,
    mistakes INT DEFAULT 0,
    practice_date DATE NOT NULL,
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE skill_gaps (
    gap_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    skill_name VARCHAR(100),
    current_level VARCHAR(50),
    required_level VARCHAR(50),
    gap_level VARCHAR(50),
    recommendation TEXT,
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE learning_paths (
    path_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    career VARCHAR(100),
    stage INT,
    topic VARCHAR(150),
    status VARCHAR(30) DEFAULT 'Upcoming',
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    task_name VARCHAR(200),
    category VARCHAR(100),
    due_date DATE,
    priority VARCHAR(30),
    status VARCHAR(30) DEFAULT 'Pending',
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    message TEXT,
    notification_type VARCHAR(50),
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

INSERT INTO skills(skill_name, category) VALUES
('Java','Programming'),('Python','Programming'),('C++','Programming'),
('Data Structures','Algorithms'),('Algorithms','Algorithms'),('SQL','Database'),
('HTML','Web'),('CSS','Web'),('JavaScript','Web'),('Aptitude','Placement'),
('Communication','Career'),('Git','Tools');

INSERT INTO courses(course_name, category, difficulty, resource_url) VALUES
('Algorithms Practice','Algorithms','Easy','https://www.codechef.com/practice#algorithms'),
('CodeChef Learn','Courses','Beginner','https://www.codechef.com/learn#header'),
('Aptitude Practice','Aptitude','Medium','https://www.geeksforgeeks.org/aptitude/aptitude-questions-and-answers/'),
('Easy Projects','Projects','Easy','https://www.codechef.com/practice#easy-projects'),
('Interview Practice','Interview','Medium','https://www.codechef.com/practice#interview'),
('Skill Tests','Assessment','Medium','https://www.codechef.com/skill-tests');

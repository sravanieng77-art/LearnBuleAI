# LearnBule AI

AI-powered personalized learning dashboard for engineering students.

## Stack
- Frontend: HTML, CSS, JavaScript
- Backend: Java Servlet/JDBC scaffold
- Database: MySQL

## Demo
Open `frontend/index.html` in a browser for the frontend demo.

## Backend
The `backend` folder contains Java model/DAO/util/controller scaffolding and the MySQL schema.
Add your Servlet container (Tomcat) and MySQL Connector/J JAR, then configure the database credentials in `DBConnection.java`.

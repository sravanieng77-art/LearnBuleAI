package com.learnbule.model;

public class Student {
    private int studentId;
    private String name;
    private String email;
    private String college;
    private String branch;
    private int year;
    private int semester;
    private String section;
    private String careerGoal;

    public int getStudentId(){ return studentId; }
    public void setStudentId(int studentId){ this.studentId=studentId; }
    public String getName(){ return name; }
    public void setName(String name){ this.name=name; }
    public String getEmail(){ return email; }
    public void setEmail(String email){ this.email=email; }
    public String getCollege(){ return college; }
    public void setCollege(String college){ this.college=college; }
    public String getBranch(){ return branch; }
    public void setBranch(String branch){ this.branch=branch; }
    public int getYear(){ return year; }
    public void setYear(int year){ this.year=year; }
    public int getSemester(){ return semester; }
    public void setSemester(int semester){ this.semester=semester; }
    public String getSection(){ return section; }
    public void setSection(String section){ this.section=section; }
    public String getCareerGoal(){ return careerGoal; }
    public void setCareerGoal(String careerGoal){ this.careerGoal=careerGoal; }
}

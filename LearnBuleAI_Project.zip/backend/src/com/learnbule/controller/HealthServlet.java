package com.learnbule.controller;

import com.learnbule.util.DBConnection;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/api/health")
public class HealthServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        try(var con=DBConnection.getConnection()){
            resp.getWriter().print("{\"status\":\"ok\",\"database\":\"connected\"}");
        } catch(Exception e) {
            resp.setStatus(500);
            resp.getWriter().print("{\"status\":\"error\",\"message\":\"Database connection failed\"}");
        }
    }
}

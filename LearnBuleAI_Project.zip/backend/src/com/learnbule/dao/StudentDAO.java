package com.learnbule.dao;

import com.learnbule.model.Student;
import com.learnbule.util.DBConnection;
import java.sql.*;

public class StudentDAO {
    public int create(Student s, String passwordHash) throws SQLException {
        String sql = "INSERT INTO students(name,email,password_hash,college,branch,year,semester,section,career_goal) VALUES(?,?,?,?,?,?,?,?,?)";
        try(Connection con=DBConnection.getConnection(); PreparedStatement ps=con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)){
            ps.setString(1,s.getName()); ps.setString(2,s.getEmail()); ps.setString(3,passwordHash);
            ps.setString(4,s.getCollege()); ps.setString(5,s.getBranch()); ps.setInt(6,s.getYear());
            ps.setInt(7,s.getSemester()); ps.setString(8,s.getSection()); ps.setString(9,s.getCareerGoal());
            ps.executeUpdate();
            try(ResultSet rs=ps.getGeneratedKeys()){ if(rs.next()) return rs.getInt(1); }
        }
        return -1;
    }
}

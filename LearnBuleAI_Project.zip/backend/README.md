# Java backend setup

1. Install JDK 17+ and Apache Tomcat 10+.
2. Import `database/learnbule_ai.sql` into MySQL.
3. Add MySQL Connector/J and Jakarta Servlet API to your IDE/server.
4. Change `PASSWORD` in `DBConnection.java`.
5. Deploy the Java web application to Tomcat.
6. Test `/api/health`.

The included frontend is a polished browser demo. Connect its forms/API calls to the Java servlets as the next integration step.
